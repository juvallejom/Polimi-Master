#include <cmath>
#include <iostream>

#include "RKSolver.hpp"


RKSolver::RKSolver(double step, const BaseEquation &eq,
                   const std::vector<std::vector<double>> &a_,
                   const std::vector<double> &b_,
                   const std::vector<double> &c_,
                   double tolerance, double min_step)
    : h(step), equation(eq), a(a_), b(b_), c(c_), tol(tolerance), hmin(min_step)
{
    assert(b.size() == c.size() && a.size() == a[0].size() && b.size() == a.size());
    n_stages = b.size();
    method_name = "User defined";
    // The solution at t=0 coincides with the initial condition
    solution.push_back( equation.get_x0() );
    times.push_back( equation.get_tin() );
}

Rnvector RKSolver::fixed_point(const EquationFunction &f, const double tn,
                               const Rnvector &un, const double h_local,
                               const Rnvector &sum_aij_Kj, const size_t i) const
{
    unsigned n_iter = 0;
    unsigned Max_iter = 10000;

    Rnvector K0 = un;
    Rnvector K1 = f.eval(tn + c[i] * h_local,
                    un + h_local * sum_aij_Kj + h_local * a[i][i] * K0);
    double error = compute_error(K0, K1);
    K0 = K1;

    while (error > fixed_point_tol && n_iter < Max_iter)
    {
        K1 = f.eval(tn + c[i] * h_local,
               un + h_local * sum_aij_Kj + h_local * a[i][i] * K0);
        error = compute_error(K0, K1);
        K0 = K1;
        n_iter++;
    }

    if (n_iter == Max_iter)
    {
        std::cerr << "Fixed point algorithm cannot converge. Try with a smaller step size."
                  << std::endl;
        exit(1);
    }

    return K0;
}

double RKSolver::compute_error(const Rnvector &K0, const Rnvector &K1) const
{
    double error = 0;
    for (size_t k = 0; k < K0.size(); k++)
        error += std::abs(K0[k] - K1[k]);
    return error;
}

bool RKSolver::is_implicit(const size_t K_index) const
{
    return (a[K_index][K_index] != 0);
}

void RKSolver::print() const
{
    // Print the equation
    std::cout << "Equation:" << std::endl;
    std::cout << equation.get_f().f_string << "\t in [" <<
    equation.get_tin() << "," << equation.get_tfin() << "]" << std::endl;
    std::cout << "y(" << equation.get_tin() << ") = ";
    for( auto i : equation.get_x0() )
        std::cout << i << " ";
    std::cout << std::endl << std::endl;
    //Print the solver specifications
    print_solver_spec();
}

void RKSolver::save_sol_to_file( const std::string &file_name ) const
{
    std::ofstream output_stream{ file_name };
    if( !output_stream )
    {
        std::cerr << "Cannot open input file: \"" << file_name << "\"" <<
            std::endl;
        return;
    }

    // Save the computed solution
    output_stream << "Solution:" << std::endl;
    for( auto un : solution )
    {
        for( auto val : un )
            output_stream << val << " ";
        output_stream << std::endl;
    }

    // Save time instants
    output_stream << "Time instants:" << std::endl;
    for( auto tn : times )
        output_stream << tn << " ";
    output_stream << std::endl;
}

void RKSolver::print_solver_spec() const
{
    std::cout << "Solved using: Adaptive Runge-Kutta (" << method_name << ")" << std::endl;
    std::cout << "Starting h = " << h << std::endl;
    std::cout << "Minimum h  = " << hmin << std::endl;
    std::cout << "Tolerance  = " << tol << std::endl;
    std::cout << std::endl;
}

Rnvector RKSolver::single_step(const double tn, const Rnvector &un,
    const double hn) const
{
    // Your code goes here
    // N.B.: the initial condition (t_0, u_0) has already been included in the
    // `times` and `solution` vectors by the class constructor (see above)
}

void RKSolver::solve()
{
    // Your code goes here
}
